modules = {
    stripe {
        resource id:'stripe', url:[plugin:'stripe', dir:'js', file:'stripe-v1.js'], disposition:'head', exclude:'minify'   
    }
}