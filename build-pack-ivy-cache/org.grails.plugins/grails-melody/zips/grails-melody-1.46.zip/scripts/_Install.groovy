ant.copy(file: "${pluginBasedir}/src/samples/GrailsMelodyConfig.groovy",
	todir: "${basedir}/grails-app/conf")